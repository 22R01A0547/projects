
# covid19_api from Postman
# a summary of new and total cases per country updated daily
endPointUrl = 'https://api.covid19api.com/summary'
