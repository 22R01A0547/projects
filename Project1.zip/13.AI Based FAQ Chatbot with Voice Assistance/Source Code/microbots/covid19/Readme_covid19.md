# COVID-19

## API: A summary of new and total cases per country updated daily.
Using a free API from https://api.covid19api.com/summary