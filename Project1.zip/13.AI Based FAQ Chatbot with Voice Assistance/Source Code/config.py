google_api_key = ""  # add config key
weather_api_key = ""  # add config key


# adding domains for intent classification
domains = ['music', 'restaurant', 'weather']

geolocation_api = "https://geolocation-db.com/json"
weather_temperature_format = "metric"  # It gives temperature in celsius
