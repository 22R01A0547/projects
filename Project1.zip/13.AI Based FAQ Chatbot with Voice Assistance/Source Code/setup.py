import setuptools

setuptools.setup(
    setup_requires=['pbr>=1.8'],
    pbr=True)
